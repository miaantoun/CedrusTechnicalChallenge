import { LoginModel } from './loginModel';

describe('Loginmodel', () => {
  it('should create an instance', () => {
    expect(new LoginModel()).toBeTruthy();
  });
});
