import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatButtonModule} from "@angular/material/button";
import {MatInputModule} from "@angular/material/input";
import { FormsModule } from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { MenuComponent } from './components/menu/menu.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import {HttpClient, HttpClientModule} from "@angular/common/http";
import { SignupComponent } from './components/signup/signup.component';
import {MdbFormsModule} from "mdb-angular-ui-kit/forms";
import { WatchedComponent } from './components/watched/watched.component';
import { AgGridModule } from 'ag-grid-angular';

const appRoutes = [
  {path: 'login', component: LoginComponent},
  {path: 'menu', component: MenuComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'watched', component: SignupComponent},
  {path: '', redirectTo: '/login', pathMatch:'full'},
  {path: '**', component: PageNotFoundComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    PageNotFoundComponent,
    SignupComponent,
    WatchedComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    FormsModule,
    HttpClientModule,
    MdbFormsModule,
    AgGridModule.withComponents([]),

  ],
  providers: [],
  bootstrap: [AppComponent]
})


export class AppModule {
}
