import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
  username: string = "";
  url : string = "http://192.168.190.231:5000/";
  constructor() { }
}
