import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {LoginModel} from "../../model/loginModel";
import {SharedServiceService} from "../../services/shared-service.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide;
  usernameText: string;
  passwordText: string;
  result : number;

  url : string;

  constructor(private http: HttpClient, private router: Router, private sharedService: SharedServiceService) {
    this.url=""
    this.hide = true;
    this.usernameText = "";
    this.passwordText = "";
    this.result = 0;
  }

  ngOnInit(): void {
    this.result=0;
    this.url=this.sharedService.url;
  }

  loginVerification(): void{
    const headerDict = {"Access-Control-Allow-Origin":"*",
      "Access-Control-Allow-Methods":"GET, OPTIONS, POST",
      "Content-Type":"application/json"
    }
    const requestOptions = {headers: new HttpHeaders(headerDict)}

    this.http.post<LoginModel>(this.url+"login",{"username":this.usernameText, "password":this.passwordText}, requestOptions )
      .subscribe((data:any) => {
        console.log(data);
        console.log(data.confirmed);
        this.result = data.confirmed;
        if(this.result==1) {
          this.sharedService.username = this.usernameText;
          this.router.navigate(["menu"]);
        }
        if(this.result==0){
          console.log("Wrong password!")
        }
      })


  }

  updateUser(event:any) {
    this.usernameText = event.target.value;
  }

  updatePass(event:any) {
    this.passwordText = event.target.value;
  }

  goToSignup() {
    this.router.navigate(["signup"]);
  }
}
