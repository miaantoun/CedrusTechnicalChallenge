import { Component, OnInit } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {LoginModel} from "../../model/loginModel";
import {Router} from "@angular/router";
import {SharedServiceService} from "../../services/shared-service.service";

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  hide;
  usernameText: string;
  passwordText: string;
  result : number;

  url : string;

  constructor(private http: HttpClient, private router: Router, private sharedService: SharedServiceService) {
    this.url= ""
    this.hide = true;
    this.usernameText = "";
    this.passwordText = "";
    this.result = 0;
  }

  ngOnInit(): void {
    this.url=this.sharedService.url;
    this.result=0;
  }

  signUpVerification(): void {
    const headerDict = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, OPTIONS, POST",
      "Content-Type": "application/json"
    }
    const requestOptions = {headers: new HttpHeaders(headerDict)}

    this.http.post<LoginModel>(this.url + "register", {
      "username": this.usernameText,
      "password": this.passwordText
    }, requestOptions)
      .subscribe((data: any) => {
        console.log(data);
        console.log(data.confirmed);
        this.result = data.confirmed;
        if (this.result == 1) {
          this.sharedService.username = this.usernameText;
          this.router.navigate(["menu"]);
        }
      })


  }

  updateUser(event: any) {
    this.usernameText = event.target.value;
  }

  updatePass(event: any) {
    this.passwordText = event.target.value;
  }

  goToLogin() {
    this.router.navigate(["login"]);
  }

}
