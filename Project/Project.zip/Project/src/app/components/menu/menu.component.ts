import { Component, OnInit } from '@angular/core';
import {MdbCollapseModule} from "mdb-angular-ui-kit/collapse";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {SharedServiceService} from "../../services/shared-service.service";

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  toggleFirstExample: MdbCollapseModule;
  columnDefs = [
    { field: '_id' , sortable: true, filter: true, hide: "true"},
    { field: 'Name' , sortable: true, filter: true, hide: "false"},
    { field: 'Genre' , sortable: true, filter: true, hide: "false"},
    { field: 'YearReleased', sortable: true, filter: true, hide: "false"},
    { field: 'Description', sortable: true, filter: true, hide: "false"},
    { field: 'Rating', sortable: true, filter: true, hide: "false"},
    { field: 'NbrUserRating', sortable: true, filter: true, hide: "false"},
    { field: 'Classification', sortable: true, filter: true, hide: "false"}
  ];
  dataset: any = [];
  url:string;

  gridOptions : any = {
    rowData: this.dataset,
    columnDefs: this.columnDefs
  }
  constructor(private http:HttpClient, private sharedService:SharedServiceService) {
    this.url="";
    this.toggleFirstExample = false
    this.dataset=[];
  }

  ngOnInit(): void {
    this.url=this.sharedService.url;
    this.dataset=[];
    const headerDict = {"Access-Control-Allow-Origin":"*",
      "Access-Control-Allow-Methods":"GET, OPTIONS, POST",
      "Content-Type":"application/json"
    }
    const requestOptions = {headers: new HttpHeaders(headerDict)}
    this.http.get(this.url+"movieslist",requestOptions).subscribe((data:any)=>{this.dataset = data;
    console.log(this.dataset)})
  }

  searchMovies(event: any) {
    const headerDict = {"Access-Control-Allow-Origin":"*",
      "Access-Control-Allow-Methods":"GET, OPTIONS, POST",
      "Content-Type":"application/json"
    }
    const requestOptions = {headers: new HttpHeaders(headerDict)}
    this.http.post(this.url+"movieslist",event.target.value,requestOptions).subscribe((data:any)=>{})
  }

}
