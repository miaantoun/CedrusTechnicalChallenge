import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watched',
  templateUrl: './watched.component.html',
  styleUrls: ['./watched.component.css']
})
export class WatchedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
